//: Playground - noun: a place where people can play

import UIKit


/* Generacion de lista de 100 numeros incluiod el 100
 
 */

var series = 1...100
for serie in series {
    
    switch serie {
        
    case 1,3,7,9,11,13,17,19,21,23,27,29,41,43,47,49,51,53,57,59,53,57,59,61,63,67,69,71,73,77,79,81,83,87,89,91,93,97,99:
        print ("\(serie) es impar")
    
    case 2,4,6,8,2,14,16,18,22,24,26,28,42,44,46,48,52,54,56,58,62,64,66,68,72,76,78,82,84,86,88,92,94,96,98:
        print ("\(serie) es par")
        
    case 5,10,15,20,25,30,40,45,50,55,60,65,70,75,80,85,90,95,100:
        print ("\(serie) BINGO")
        
    default:
        print("\(serie) Viva Swift1!!")
    }
}
